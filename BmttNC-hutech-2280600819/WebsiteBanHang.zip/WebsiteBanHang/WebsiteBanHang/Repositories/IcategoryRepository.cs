﻿using WebsiteBanHang.Models;

namespace WebsiteBanHang.Repositories
{
    public interface IcategoryRepository
    {
        IEnumerable<Category> GetAllCategories();
    }
}
